import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutComponent } from './about/about.component';
import { RefundPolicyComponent } from './refund-policy/refund-policy.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { TermAndConditionComponent } from './term-and-condition/term-and-condition.component';
import { MyhomeComponent } from './myhome/myhome.component';

@NgModule({
  declarations: [MyhomeComponent, AboutComponent, RefundPolicyComponent, PrivacyPolicyComponent, TermAndConditionComponent ],
  imports: [
    CommonModule
  ]
})
export class HomeModule { }
