import { Route } from '@angular/router';
import { HomeComponent } from './home.component';
import { MyhomeComponent } from './myhome/myhome.component';
import { AboutComponent } from './about/about.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { RefundPolicyComponent } from './refund-policy/refund-policy.component';
import { TermAndConditionComponent } from './term-and-condition/term-and-condition.component';

export const HomeRoutes: Route[] = [
    {
        path: '',
        component: HomeComponent,
        children: [
                    { path: '', component: MyhomeComponent },
                    { path: 'about', component: AboutComponent },
                    { path: 'privacy-policy', component:PrivacyPolicyComponent },
                    { path: 'refund-policy', component:RefundPolicyComponent},
                    { path: 'term-and-condition', component:TermAndConditionComponent}
                ]
        }
]