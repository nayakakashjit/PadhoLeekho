import { Routes } from '@angular/router';
import { HomeRoutes } from './home/home.router';
import { IndexRoutes } from './index/index.router';
import { PagenotfoundRoutes } from './page-not-found/pagenotfound.router';


export const routes: Routes = [...HomeRoutes,...IndexRoutes,...PagenotfoundRoutes];