import { Injectable } from '@angular/core';
import { ApiService } from '../../../../core/services';
import { of, Observable,  } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(
    private apiService: ApiService
  ) { }

  callLogin(): Observable<any> {
    return this.apiService.post('/api/rest/authentication/signin/index',{
      "emailphone": "test1@gmail.com",
      "password": "qwer1234",
      "firebase_token": 1,

    })
  }
}
