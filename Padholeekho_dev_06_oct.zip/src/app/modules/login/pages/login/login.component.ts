import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services';
import { tap, map, finalize, catchError, } from 'rxjs/operators';
import { of, throwError, from } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isLoading: any;
  error: any;
  constructor(
    private loginService: LoginService
  ) { }

  ngOnInit() { 
    this.loginService.callLogin().pipe(
      tap(response => {
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

}
